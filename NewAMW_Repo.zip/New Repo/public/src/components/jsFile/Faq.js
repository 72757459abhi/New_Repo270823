import React from 'react'
import classes from '../cssFile/Faq.module.css';

const Faq = () => {
  return (
    <main className={classes.profile}>
      <h2>Frequently Ask Question </h2>
      <p>snjhs jhjwnjsnwkk kwjkw kkwjjkw kkwjjkw</p>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore, laudantium ipsam? Voluptatum perspiciatis in aliquam, vitae hic modi totam sint nisi autem nobis maiores quas odio voluptate maxime saepe ducimus.</p>
    </main>
  );
};

export default Faq;
