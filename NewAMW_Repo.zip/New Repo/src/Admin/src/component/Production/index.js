import React, { useState, useEffect } from "react"
import { AgGridReact } from 'ag-grid-react';
import { useNavigate } from "react-router-dom";

import axios from "axios";
import 'ag-grid-community/styles//ag-grid.css';
import 'ag-grid-community/styles//ag-theme-alpine.css';
import AddNewItem from "./AddNewItem";
const Production = () => {
  const url = process.env.REACT_APP_SERVICE_ID

  const [showModal, setShowModal] = useState(false)


  const nav = useNavigate();


  const inOutFunction = () => {
    nav("/admin/InOutMaterial");
  };


  



  const updateBtn = (props) => {

    const buttonClicked = () => {
      console.log(props.data)
      axios.post(url + "editData", props.data).then((res) => {
        setRowData(res.data)

      })

    };

    return (
      <span>
        <div className='agButton'>
          <button className="AdBtn" onClick={() => buttonClicked()}>Update </button>
        </div>
      </span>

    );
  };
  const [coldef, setcoldef] = useState([
    { field: 'Item', editable: true, width: 150 },
    { field: 'Description', editable: true, width: 250 },
    { field: 'Size', editable: true , width: 90},
    { field: 'Product', editable: true, width: 130 },
    // { field: 'ProductId' },
    { field: 'Price', editable: true , width: 130},
    { headerName: "Total Quatity", field: 'Quantity', editable: true, width: 130 },
    { field: 'Weight', editable: true , width: 130},
    { field: 'Action', cellRenderer: updateBtn, width: 125 }
  ]);
  const [rowData, setRowData] = useState()

  // 
  useEffect(() => {
    let arr = []
    axios.get(url + "jsonData").then((res) => {
      console.log(res.data)

      res.data.map((i) => {
        let obj = {}
        obj['Item'] = i.item
        obj['Description'] = i.description
        obj['Price'] = i.price
        obj['Product'] = i.product
        obj['ProductId'] = i.productId
        obj['Quantity'] = i.quantity
        obj['Size'] = i.size
        obj['Weight'] = i.weight
        obj["_id"] = i._id
        arr.push(obj)

      })


      console.log(arr)
      setRowData(arr)

    })
  }, [])
















  return (<>
    <h3>Production</h3>

    <div className="ag-theme-alpine agTable" >
      <AgGridReact columnDefs={coldef} rowData={rowData}
        rowSelection={'multiple'}
        rowMultiSelectWithClick={true}
      />
    </div>

    <div className="Button">
      <button className="AdBtn" type="submit" onClick={() => {inOutFunction(true) }}>In-Out Material</button>
      <button className="AdBtn" type="submit" onClick={() => { setShowModal() }}>Add New Item</button>
    </div>

    {showModal && <AddNewItem show={showModal} setShowModal={setShowModal} />}

  </>)
}

export default Production;